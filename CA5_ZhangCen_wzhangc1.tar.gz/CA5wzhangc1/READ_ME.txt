make clean all
./Driver.exe flight_file.txt

Input Dallas (or any other city)
Input Pueblo (or any other city)
Input a valid time in hh:mmMM format

Input "Quit" to exit

*This program does not have error checking for input
